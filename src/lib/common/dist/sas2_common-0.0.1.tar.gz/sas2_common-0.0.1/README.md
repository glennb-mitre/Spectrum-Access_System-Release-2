# Common modules

This defines common data structures and operational configuration.
